#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?Set DATABASE_URL to a disposable PostgreSQL test database}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -c \
  "DROP TABLE IF EXISTS evaluation, application, internship, mentor, student CASCADE; DROP FUNCTION IF EXISTS enforce_application_status_transition() CASCADE;"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$ROOT/migrations/001_initial_schema.sql"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$ROOT/fixtures/001_seed.sql"

run_expected_failure() {
  local label="$1"
  local sql="$2"
  if psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -c "$sql" >/dev/null 2>&1; then
    echo "FAIL: $label was accepted"
    exit 1
  else
    echo "PASS: $label was rejected"
  fi
}

run_expected_failure "BR-01 duplicate application" \
  "INSERT INTO application (student_id, internship_id, status) VALUES (1, 1, 'submitted')"
run_expected_failure "BR-02 orphan student" \
  "INSERT INTO application (student_id, internship_id, status) VALUES (99999, 2, 'submitted')"
run_expected_failure "BR-03 invalid status value" \
  "INSERT INTO application (student_id, internship_id, status) VALUES (1, 2, 'maybe')"
run_expected_failure "BR-03 invalid transition" \
  "UPDATE application SET status = 'completed' WHERE application_id = 2"
run_expected_failure "BR-04 invalid date range" \
  "INSERT INTO internship (mentor_id, title, department, start_date, end_date, status) VALUES (1, 'Invalid dates fixture', 'Engineering', '2027-03-01', '2027-02-01', 'planned')"
run_expected_failure "BR-05 orphan evaluation" \
  "INSERT INTO evaluation (application_id, mentor_id, score) VALUES (99999, 1, 70)"
run_expected_failure "BR-05 invalid score" \
  "INSERT INTO evaluation (application_id, mentor_id, score) VALUES (1, 1, 101)"
run_expected_failure "retention delete restriction" \
  "DELETE FROM student WHERE student_id = 1"

echo "All negative tests passed."
