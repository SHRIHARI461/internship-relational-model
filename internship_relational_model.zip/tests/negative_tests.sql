-- Each block intentionally violates a rule. Run each block separately.
-- A successful run means PostgreSQL rejects the statement with a constraint/trigger error.
-- Assumes migrations/001_initial_schema.sql and fixtures/001_seed.sql have been applied.

-- TEST 1: Duplicate application (BR-01) -- expect unique_violation
INSERT INTO application (student_id, internship_id, status)
VALUES (1, 1, 'submitted');

-- TEST 2: Orphan student (BR-02) -- expect foreign_key_violation
INSERT INTO application (student_id, internship_id, status)
VALUES (99999, 2, 'submitted');

-- TEST 3: Unknown status (BR-03) -- expect check_violation
INSERT INTO application (student_id, internship_id, status)
VALUES (1, 2, 'maybe');

-- TEST 4: Invalid status transition (BR-03) -- expect check_violation from trigger
UPDATE application SET status = 'completed' WHERE application_id = 2;

-- TEST 5: End date before start date (BR-04) -- expect check_violation
INSERT INTO internship (mentor_id, title, department, start_date, end_date, status)
VALUES (1, 'Invalid dates fixture', 'Engineering', '2027-03-01', '2027-02-01', 'planned');

-- TEST 6: Evaluation references nonexistent application (BR-05) -- expect foreign_key_violation
INSERT INTO evaluation (application_id, mentor_id, score)
VALUES (99999, 1, 70);

-- TEST 7: Evaluation score outside range (BR-05) -- expect check_violation
INSERT INTO evaluation (application_id, mentor_id, score)
VALUES (1, 1, 101);

-- TEST 8: Parent delete is restricted while referenced (retention) -- expect foreign_key_violation
DELETE FROM student WHERE student_id = 1;
