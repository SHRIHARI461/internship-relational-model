# Rule-to-constraint matrix

| ID | Non-negotiable business rule | Enforcement | Negative test |
|---|---|---|---|
| BR-01 | A student may apply to the same internship only once. | `UNIQUE (student_id, internship_id)` on `application`. | Duplicate application insert |
| BR-02 | Every application must reference an existing student and internship. | `NOT NULL` plus foreign keys with `ON DELETE RESTRICT`. | Orphan student / internship reference |
| BR-03 | Application status must be one of the defined values and transitions must follow the lifecycle. | `CHECK` constraint plus trigger on status updates. | Unknown status / invalid transition |
| BR-04 | Internship end date must be on or after start date. | `CHECK (end_date >= start_date)`. | End date before start date |
| BR-05 | Every evaluation must reference an existing application and mentor, and score must be between 0 and 100. | Foreign keys, `NOT NULL`, `CHECK (score BETWEEN 0 AND 100)`. | Orphan evaluation / invalid score |

## Transaction boundaries
- Submit an application in a single `INSERT`; unique and foreign-key constraints arbitrate concurrent requests safely.
- Change application status with a single `UPDATE`; the trigger validates the transition atomically.
- If application creation requires related audit/outbox records in a real app, insert all of them in one transaction.
- Avoid application-side “check then insert” as the sole protection for uniqueness; concurrent transactions can race. The database constraint is authoritative.

## Status lifecycle
`submitted -> under_review -> accepted | rejected | withdrawn`
`accepted -> in_progress | withdrawn`
`in_progress -> completed | withdrawn`
Terminal states: `rejected`, `withdrawn`, `completed`.
