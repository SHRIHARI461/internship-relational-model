# Conceptual ER diagram

```mermaid
erDiagram
    STUDENT ||--o{ APPLICATION : submits
    INTERNSHIP ||--o{ APPLICATION : receives
    MENTOR ||--o{ INTERNSHIP : supervises
    APPLICATION ||--o{ EVALUATION : has
    MENTOR ||--o{ EVALUATION : writes

    STUDENT {
        bigint student_id PK
        text full_name
        text email UK
        timestamptz created_at
    }
    MENTOR {
        bigint mentor_id PK
        text full_name
        text email UK
    }
    INTERNSHIP {
        bigint internship_id PK
        bigint mentor_id FK
        text title
        text department
        date start_date
        date end_date
        text status
    }
    APPLICATION {
        bigint application_id PK
        bigint student_id FK
        bigint internship_id FK
        text status
        timestamptz applied_at
        timestamptz updated_at
        UK student_id_internship_id
    }
    EVALUATION {
        bigint evaluation_id PK
        bigint application_id FK
        bigint mentor_id FK
        smallint score
        text comments
        timestamptz evaluated_at
    }
```

## Cardinalities and retention
- Student `1 : 0..N` Application.
- Internship `1 : 0..N` Application.
- Mentor `1 : 0..N` Internship.
- Application `1 : 0..N` Evaluation.
- Mentor `1 : 0..N` Evaluation.
- Application and evaluation history is retained. Foreign keys use `ON DELETE RESTRICT` so parent records cannot be removed while referenced.
- Contact information is operational personal data; establish a documented retention period and access policy. This sample does not automatically delete records because retention duration depends on organizational/legal requirements.
