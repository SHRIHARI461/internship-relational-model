BEGIN;

INSERT INTO student (student_id, full_name, email) VALUES
    (1, 'Asha Kumar', 'asha.kumar@example.com'),
    (2, 'Rahul Prasad', 'rahul.prasad@example.com')
ON CONFLICT (student_id) DO NOTHING;

INSERT INTO mentor (mentor_id, full_name, email) VALUES
    (1, 'Meera Iyer', 'meera.iyer@example.com'),
    (2, 'Arun Dev', 'arun.dev@example.com')
ON CONFLICT (mentor_id) DO NOTHING;

INSERT INTO internship
    (internship_id, mentor_id, title, department, start_date, end_date, status)
VALUES
    (1, 1, 'SQL & Database Engineering Intern', 'Engineering', '2026-11-01', '2027-01-31', 'open'),
    (2, 2, 'Data Quality Intern', 'Data', '2026-11-15', '2027-02-15', 'planned')
ON CONFLICT (internship_id) DO NOTHING;

INSERT INTO application (application_id, student_id, internship_id, status)
VALUES
    (1, 1, 1, 'under_review'),
    (2, 2, 1, 'submitted')
ON CONFLICT (application_id) DO NOTHING;

INSERT INTO evaluation (evaluation_id, application_id, mentor_id, score, comments)
VALUES
    (1, 1, 1, 88, 'Strong SQL fundamentals and careful validation.')
ON CONFLICT (evaluation_id) DO NOTHING;

-- Keep identity sequences ahead of explicit fixture IDs.
SELECT setval(pg_get_serial_sequence('student','student_id'),
              GREATEST((SELECT COALESCE(MAX(student_id), 1) FROM student), 1), true);
SELECT setval(pg_get_serial_sequence('mentor','mentor_id'),
              GREATEST((SELECT COALESCE(MAX(mentor_id), 1) FROM mentor), 1), true);
SELECT setval(pg_get_serial_sequence('internship','internship_id'),
              GREATEST((SELECT COALESCE(MAX(internship_id), 1) FROM internship), 1), true);
SELECT setval(pg_get_serial_sequence('application','application_id'),
              GREATEST((SELECT COALESCE(MAX(application_id), 1) FROM application), 1), true);
SELECT setval(pg_get_serial_sequence('evaluation','evaluation_id'),
              GREATEST((SELECT COALESCE(MAX(evaluation_id), 1) FROM evaluation), 1), true);

COMMIT;
