# Business Rules to Executable Relational Model

Reference implementation: PostgreSQL 14+.

> The original internship-management brief was not supplied. This is a representative model with explicit assumptions; revise the rules and fields against the actual brief before treating it as authoritative.

## Contents
- `docs/er_diagram.md` — conceptual ER diagram (Mermaid)
- `docs/rule_constraint_matrix.md` — five non-negotiable rules mapped to enforcement
- `migrations/001_initial_schema.sql` — repeatable initial schema migration
- `fixtures/001_seed.sql` — representative valid seed data
- `tests/negative_tests.sql` — tests that must fail for invalid states/orphan records
- `tests/run_negative_tests.sh` — helper to execute each negative test in an isolated transaction

## Run
Create an empty PostgreSQL database, then run:

```sh
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/001_initial_schema.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f fixtures/001_seed.sql
```

For a negative test, each statement is expected to fail. Run the statements individually, or use the helper script against a test database:

```sh
DATABASE_URL="postgresql://user:password@localhost:5432/internship_test" ./tests/run_negative_tests.sh
```

The script re-creates the schema, loads fixtures, and verifies that each invalid insert/update is rejected. Do not run it against a database containing important data.

## Design assumptions
1. A student may apply to a given internship only once.
2. An application has one student and one internship.
3. Status values are constrained to a known lifecycle.
4. Internship end date cannot precede its start date.
5. Evaluations must refer to an existing application and a valid mentor; score is from 0 to 100.
6. Application and evaluation records are retained for audit; deletion is restricted instead of cascading away historical records.
7. Application lifecycle transitions are: `submitted -> under_review -> accepted|rejected|withdrawn`; `accepted -> in_progress`; `in_progress -> completed|withdrawn`. A database trigger enforces allowed transitions.

## Note on repeatability
The migration uses `CREATE TABLE IF NOT EXISTS` and `CREATE OR REPLACE FUNCTION` so it can be re-applied to a clean/compatible database. In production, use a migration tool (Flyway, Liquibase, Sqitch, or framework migrations) and version each change rather than editing an already-applied migration.
